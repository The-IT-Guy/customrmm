#!/usr/bin/env bash
# CustomRMM server installer (Linux + Docker).
# Run from the unpacked customrmm/ directory.
set -euo pipefail

PUBLIC_URL="${PUBLIC_URL:-http://localhost:8000}"

if [[ "$EUID" -ne 0 ]]; then
  echo "Please run with sudo." >&2
  exit 1
fi

if [[ ! -f docker-compose.yml ]]; then
  echo "Run this from the customrmm/ project directory (where docker-compose.yml lives)." >&2
  exit 1
fi

if ! command -v docker >/dev/null 2>&1; then
  echo "==> Installing Docker..."
  curl -fsSL https://get.docker.com | sh
fi

if [[ ! -f .env ]]; then
  cp .env.example .env
  SECRET=$(python3 scripts/generate-secret.py)
  # Use | as sed delimiter since SECRET may contain /
  sed -i "s|^SECRET_KEY=.*|SECRET_KEY=$SECRET|" .env
  sed -i "s|^PUBLIC_URL=.*|PUBLIC_URL=$PUBLIC_URL|" .env
  echo "==> Wrote .env (PUBLIC_URL=$PUBLIC_URL, SECRET_KEY generated)"
fi

docker compose up -d --build

echo ""
echo "==> Done."
echo "    Open ${PUBLIC_URL}/setup-admin to create the admin account."
echo "    Logs:  docker compose logs -f rmm"
echo "    Stop:  docker compose down"
