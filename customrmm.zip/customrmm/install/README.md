# Server Installation

## Linux + Docker (recommended)

From inside the unpacked `customrmm/` directory:

```bash
sudo PUBLIC_URL=https://rmm.example.com ./install/install-server.sh
```

This will:
1. Install Docker if missing.
2. Generate a `.env` with a fresh `SECRET_KEY`.
3. Run `docker compose up -d --build`.
4. Tell you to visit `${PUBLIC_URL}/setup-admin` to create the admin account.

To upgrade later: `git pull && docker compose up -d --build`.

## Windows (native, no Docker)

From inside the unpacked `customrmm\` directory in an **elevated** PowerShell:

```powershell
$env:PUBLIC_URL = 'https://rmm.example.com'
.\install\install-server.ps1
```

This installs Python via `winget` (if missing), creates a venv, installs
dependencies, generates `.env`, and registers a scheduled task
`CustomRMM Dashboard` running uvicorn on port 8000 at boot as SYSTEM.

## Manual (any OS)

```bash
cp .env.example .env
python3 scripts/generate-secret.py    # paste into SECRET_KEY=
python3 -m venv .venv
source .venv/bin/activate              # Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

## TLS in front (Caddy example)

Put Caddy or another reverse proxy in front of the dashboard for HTTPS.
WebSocket support must be enabled — Caddy does this automatically.

```caddyfile
rmm.example.com {
    encode zstd gzip
    reverse_proxy localhost:8000
}
```

After setting up TLS, edit `.env` and set:
```
PUBLIC_URL=https://rmm.example.com
```
Then restart the server (`docker compose up -d` or restart the scheduled task).
The dashboard uses `PUBLIC_URL` to render install one-liners and to derive
the `wss://` URL agents connect to.

## Data location

- Docker: a named volume `rmm_data` mounted at `/app/data`. Inspect with
  `docker volume inspect rmm_data`.
- Native: `data/` in the project directory (SQLite database lives at `data/rmm.db`).

To back up: copy the contents of that directory while the server is stopped.

## Out of scope for v1

These are intentionally not included; see the top-level README for the full
list:

- Multi-tenancy / RBAC / 2FA
- Email or Slack alerting (alerts are dashboard-only)
- Agent auto-update
- File transfer between dashboard and agent
- Interactive PTY / VNC / RDP
