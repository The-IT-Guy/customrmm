# CustomRMM server installer (Windows, no Docker).
# Run from the unpacked customrmm\ directory in elevated PowerShell.
$ErrorActionPreference = 'Stop'

if (-not [Security.Principal.WindowsPrincipal]::new(
        [Security.Principal.WindowsIdentity]::GetCurrent()
      ).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
  Write-Error 'Please run this script in an elevated (Administrator) PowerShell.'
  exit 1
}

$PublicUrl = if ($env:PUBLIC_URL) { $env:PUBLIC_URL } else { 'http://localhost:8000' }

function Test-Cmd($n) { [bool](Get-Command $n -ErrorAction SilentlyContinue) }

if (-not (Test-Path .\app\main.py)) {
  Write-Error 'Run this from the unpacked customrmm\ directory (where .\app\main.py lives).'
  exit 1
}

if (-not (Test-Cmd 'python')) {
  Write-Host '==> Installing Python via winget...'
  if (Test-Cmd 'winget') {
    winget install -e --id Python.Python.3.12 --silent --accept-source-agreements --accept-package-agreements
  } else {
    Write-Error 'Install Python 3.12 first.'
    exit 1
  }
}

if (-not (Test-Path .\.venv)) {
  Write-Host '==> Creating venv...'
  python -m venv .venv
}

Write-Host '==> Installing dependencies...'
& .\.venv\Scripts\python.exe -m pip install --upgrade pip
& .\.venv\Scripts\python.exe -m pip install -r requirements.txt

if (-not (Test-Path .\.env)) {
  Copy-Item .\.env.example .\.env
  $secret = (& .\.venv\Scripts\python.exe .\scripts\generate-secret.py).Trim()
  (Get-Content .\.env) `
    -replace '^SECRET_KEY=.*', "SECRET_KEY=$secret" `
    -replace '^PUBLIC_URL=.*', "PUBLIC_URL=$PublicUrl" `
    | Set-Content .\.env
  Write-Host "==> Wrote .env (PUBLIC_URL=$PublicUrl, SECRET_KEY generated)"
}

# Register a scheduled task running at boot as SYSTEM
$taskName = 'CustomRMM Dashboard'
schtasks /Delete /F /TN $taskName 2>$null | Out-Null

$cwd = (Get-Location).Path
$tr = "`"$cwd\.venv\Scripts\python.exe`" -m uvicorn app.main:app --host 0.0.0.0 --port 8000"
schtasks /Create /F /SC ONSTART /RU SYSTEM /RL HIGHEST /TN $taskName /TR $tr | Out-Null
schtasks /Run /TN $taskName | Out-Null

Write-Host ""
Write-Host "==> Done."
Write-Host "    Open $PublicUrl/setup-admin to create the admin account."
Write-Host "    Stop the service:    schtasks /End /TN '$taskName'"
Write-Host "    Remove the service:  schtasks /Delete /F /TN '$taskName'"
