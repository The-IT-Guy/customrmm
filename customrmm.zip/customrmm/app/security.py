"""Password hashing & token helpers."""
from __future__ import annotations

import secrets

from passlib.context import CryptContext


pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


def hash_password(plain: str) -> str:
    return pwd_context.hash(plain)


def verify_password(plain: str, hashed: str) -> bool:
    try:
        return pwd_context.verify(plain, hashed)
    except Exception:
        return False


def gen_token(nbytes: int = 32) -> str:
    return secrets.token_urlsafe(nbytes)
