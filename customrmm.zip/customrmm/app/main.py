"""FastAPI app wiring, WebSocket endpoints, lifespan."""
from __future__ import annotations

import asyncio
import json
import logging
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from pathlib import Path

from fastapi import Depends, FastAPI, Query, WebSocket, WebSocketDisconnect
from fastapi.staticfiles import StaticFiles
from sqlalchemy import select
from starlette.middleware.sessions import SessionMiddleware

from .alerts import alert_loop
from .config import settings
from .db import AsyncSessionLocal, init_db
from .models import Agent, Command
from .routes import api_agents, api_dashboard, api_install, pages
from .ws import registry


logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s | %(message)s")
log = logging.getLogger("rmm")


@asynccontextmanager
async def lifespan(app: FastAPI):
    await init_db()
    task = asyncio.create_task(alert_loop(interval=30))
    try:
        yield
    finally:
        task.cancel()
        try:
            await task
        except asyncio.CancelledError:
            pass


app = FastAPI(title="CustomRMM", version="1.0.0", lifespan=lifespan)

app.add_middleware(
    SessionMiddleware,
    secret_key=settings.secret_key,
    session_cookie=settings.session_cookie,
    max_age=settings.session_max_age,
    same_site="lax",
    https_only=False,
)

STATIC_DIR = Path(__file__).resolve().parent / "static"
app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")

app.include_router(pages.router)
app.include_router(api_agents.router)
app.include_router(api_dashboard.router)
app.include_router(api_install.router)


@app.get("/health")
async def health():
    return {"status": "ok", "version": "1.0.0", "ts": datetime.now(timezone.utc).isoformat()}


# ------------------- WebSocket: Agent live channel -------------------

@app.websocket("/ws/agent")
async def ws_agent(websocket: WebSocket, token: str = Query(...)):
    """Live channel for agents. Auth via ?token=<auth_token> query param."""
    async with AsyncSessionLocal() as db:
        agent = (await db.execute(select(Agent).where(Agent.auth_token == token))).scalar_one_or_none()
    if not agent:
        await websocket.close(code=4401)
        return

    await websocket.accept()
    await registry.add_agent(agent.agent_id, websocket)

    # Mark online
    async with AsyncSessionLocal() as db:
        a = (await db.execute(select(Agent).where(Agent.id == agent.id))).scalar_one()
        a.online = True
        a.last_seen = datetime.now(timezone.utc)
        await db.commit()

    try:
        # Send any queued commands on connect
        async with AsyncSessionLocal() as db:
            pending = (await db.execute(
                select(Command).where(Command.agent_id == agent.id, Command.status == "queued")
                .order_by(Command.created_at).limit(50)
            )).scalars().all()
            for c in pending:
                c.status = "running"
                c.started_at = datetime.now(timezone.utc)
            await db.commit()
            for c in pending:
                await websocket.send_text(json.dumps({
                    "type": "command", "id": c.id, "shell": c.shell, "payload": c.payload,
                }))

        while True:
            raw = await websocket.receive_text()
            try:
                msg = json.loads(raw)
            except json.JSONDecodeError:
                continue
            mtype = msg.get("type")

            if mtype == "command_result":
                async with AsyncSessionLocal() as db:
                    cmd = (await db.execute(
                        select(Command).where(Command.id == msg.get("id"), Command.agent_id == agent.id)
                    )).scalar_one_or_none()
                    if cmd:
                        cmd.status = msg.get("status", "done")
                        cmd.output = (msg.get("output") or "")[:200_000]
                        cmd.exit_code = msg.get("exit_code")
                        cmd.finished_at = datetime.now(timezone.utc)
                        await db.commit()
                await registry.broadcast_dashboard({
                    "type": "command_result",
                    "agent_id": agent.agent_id,
                    "id": msg.get("id"),
                    "status": msg.get("status"),
                })
            elif mtype == "metrics":
                # Lightweight live push (full snapshot still goes via /checkin)
                await registry.broadcast_dashboard({
                    "type": "metrics",
                    "agent_id": agent.agent_id,
                    "cpu": msg.get("cpu_pct"),
                    "mem": msg.get("mem_pct"),
                    "disk": msg.get("disk_pct"),
                })
            elif mtype == "ping":
                await websocket.send_text(json.dumps({"type": "pong"}))
            elif mtype == "hello":
                # Agent introducing itself; no-op
                pass

    except WebSocketDisconnect:
        pass
    except Exception as e:  # noqa: BLE001
        log.warning("ws_agent error for %s: %s", agent.agent_id, e)
    finally:
        await registry.remove_agent(agent.agent_id, websocket)
        async with AsyncSessionLocal() as db:
            a = (await db.execute(select(Agent).where(Agent.id == agent.id))).scalar_one_or_none()
            if a:
                a.online = False
                await db.commit()


# ------------------- WebSocket: Dashboard live channel -------------------

@app.websocket("/ws/dashboard")
async def ws_dashboard(websocket: WebSocket):
    """Live channel for the dashboard. Auth via session cookie."""
    sess = websocket.session if hasattr(websocket, "session") else {}
    if not sess.get("user_id"):
        await websocket.close(code=4401)
        return
    await websocket.accept()
    await registry.add_dashboard(websocket)
    try:
        while True:
            # We mostly broadcast outward; just keep the socket alive.
            await websocket.receive_text()
    except WebSocketDisconnect:
        pass
    finally:
        await registry.remove_dashboard(websocket)
