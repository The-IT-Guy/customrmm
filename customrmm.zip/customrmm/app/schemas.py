"""Pydantic schemas for the agent <-> server protocol."""
from __future__ import annotations

from datetime import datetime
from typing import List, Optional

from pydantic import BaseModel, Field


# --- Enrollment ---

class EnrollRequest(BaseModel):
    enrollment_token: str
    hostname: str
    os_family: str
    os_version: str = ""
    arch: str = ""
    agent_version: str = "1.0.0"
    private_ip: str = ""


class EnrollResponse(BaseModel):
    agent_id: str
    auth_token: str
    websocket_url: str
    poll_interval_seconds: int = 30


# --- Checkin / metrics ---

class CheckinRequest(BaseModel):
    cpu_pct: float = 0.0
    mem_pct: float = 0.0
    disk_pct: float = 0.0
    net_rx_bps: float = 0.0
    net_tx_bps: float = 0.0
    load_1m: float = 0.0
    uptime_seconds: int = 0


class CommandPayload(BaseModel):
    id: int
    kind: str
    shell: str
    payload: str


class CheckinResponse(BaseModel):
    pending_commands: List[CommandPayload] = Field(default_factory=list)
    inventory_due: bool = False


class CommandResult(BaseModel):
    id: int
    status: str
    output: str = ""
    exit_code: Optional[int] = None


# --- Inventory ---

class SoftwareItemIn(BaseModel):
    name: str
    version: str = ""
    publisher: str = ""
    install_date: str = ""


class PatchItemIn(BaseModel):
    name: str
    kb: str = ""
    severity: str = ""
    available: bool = True


class EventItemIn(BaseModel):
    ts: Optional[datetime] = None
    source: str = ""
    level: str = "info"
    code: str = ""
    message: str = ""


class InventoryPayload(BaseModel):
    software: List[SoftwareItemIn] = Field(default_factory=list)
    patches: List[PatchItemIn] = Field(default_factory=list)
    events: List[EventItemIn] = Field(default_factory=list)
