"""Render personalized installer scripts (with server URL + enrollment token)."""
from __future__ import annotations

from textwrap import dedent


def render_agent_sh(server_url: str, token: str) -> str:
    """Bash installer for Linux + macOS."""
    return dedent(f"""\
    #!/usr/bin/env bash
    # CustomRMM agent installer (Linux / macOS)
    set -euo pipefail

    RMM_SERVER="${{RMM_SERVER:-{server_url}}}"
    RMM_TOKEN="${{RMM_TOKEN:-{token}}}"

    if [[ "$EUID" -ne 0 ]]; then
      echo "Please run with sudo." >&2
      exit 1
    fi

    UNAME="$(uname -s)"
    case "$UNAME" in
      Linux)  PLATFORM=linux ;;
      Darwin) PLATFORM=darwin ;;
      *) echo "Unsupported OS: $UNAME" >&2; exit 1 ;;
    esac

    if [[ "$PLATFORM" == "linux" ]]; then
      if command -v apt-get >/dev/null 2>&1; then
        apt-get update -y
        apt-get install -y python3 python3-venv python3-pip curl ca-certificates
      elif command -v dnf >/dev/null 2>&1; then
        dnf install -y python3 python3-pip curl ca-certificates
      elif command -v yum >/dev/null 2>&1; then
        yum install -y python3 python3-pip curl ca-certificates
      else
        echo "No supported package manager (apt/dnf/yum)." >&2
        exit 1
      fi
    else
      if ! command -v python3 >/dev/null 2>&1; then
        echo "python3 not found. Install Xcode Command Line Tools or Homebrew Python first." >&2
        exit 1
      fi
    fi

    INSTALL_DIR=/opt/customrmm-agent
    mkdir -p "$INSTALL_DIR"
    cd "$INSTALL_DIR"

    echo "==> Fetching agent..."
    curl -fsSL "$RMM_SERVER/install/agent.py" -o agent.py
    curl -fsSL "$RMM_SERVER/install/agent-requirements.txt" -o requirements.txt

    echo "==> Setting up Python venv..."
    python3 -m venv venv
    ./venv/bin/python -m pip install --upgrade pip
    ./venv/bin/python -m pip install -r requirements.txt

    cat > "$INSTALL_DIR/.env" <<EOF
    RMM_SERVER=$RMM_SERVER
    RMM_TOKEN=$RMM_TOKEN
    EOF
    chmod 600 "$INSTALL_DIR/.env"

    if [[ "$PLATFORM" == "linux" ]]; then
      echo "==> Installing systemd service..."
      cat >/etc/systemd/system/customrmm-agent.service <<EOF
    [Unit]
    Description=CustomRMM Agent
    After=network-online.target
    Wants=network-online.target

    [Service]
    Type=simple
    EnvironmentFile=$INSTALL_DIR/.env
    WorkingDirectory=$INSTALL_DIR
    ExecStart=$INSTALL_DIR/venv/bin/python $INSTALL_DIR/agent.py
    Restart=always
    RestartSec=5

    [Install]
    WantedBy=multi-user.target
    EOF
      systemctl daemon-reload
      systemctl enable --now customrmm-agent.service
      echo "==> Done. Status: systemctl status customrmm-agent"
    else
      echo "==> Installing launchd LaunchDaemon..."
      PLIST=/Library/LaunchDaemons/com.customrmm.agent.plist
      cat > "$PLIST" <<EOF
    <?xml version="1.0" encoding="UTF-8"?>
    <!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN"
      "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
    <plist version="1.0">
    <dict>
      <key>Label</key><string>com.customrmm.agent</string>
      <key>ProgramArguments</key>
      <array>
        <string>$INSTALL_DIR/venv/bin/python</string>
        <string>$INSTALL_DIR/agent.py</string>
      </array>
      <key>WorkingDirectory</key><string>$INSTALL_DIR</string>
      <key>EnvironmentVariables</key>
      <dict>
        <key>RMM_SERVER</key><string>$RMM_SERVER</string>
        <key>RMM_TOKEN</key><string>$RMM_TOKEN</string>
      </dict>
      <key>RunAtLoad</key><true/>
      <key>KeepAlive</key><true/>
      <key>StandardOutPath</key><string>/var/log/customrmm-agent.log</string>
      <key>StandardErrorPath</key><string>/var/log/customrmm-agent.log</string>
    </dict>
    </plist>
    EOF
      chown root:wheel "$PLIST"
      launchctl unload "$PLIST" 2>/dev/null || true
      launchctl load -w "$PLIST"
      echo "==> Done."
    fi
    """)


def render_agent_ps1(server_url: str, token: str) -> str:
    """PowerShell installer for Windows."""
    return dedent(f"""\
    # CustomRMM agent installer (Windows)
    $ErrorActionPreference = 'Stop'

    if (-not [Security.Principal.WindowsPrincipal]::new(
            [Security.Principal.WindowsIdentity]::GetCurrent()
          ).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {{
      Write-Error 'Please run this script in an elevated (Administrator) PowerShell.'
      exit 1
    }}

    $RmmServer = if ($env:RMM_SERVER) {{ $env:RMM_SERVER }} else {{ '{server_url}' }}
    $RmmToken  = if ($env:RMM_TOKEN)  {{ $env:RMM_TOKEN  }} else {{ '{token}' }}

    $InstallDir = 'C:\\Program Files\\CustomRMM'
    New-Item -ItemType Directory -Force -Path $InstallDir | Out-Null

    function Test-Cmd($name) {{ [bool](Get-Command $name -ErrorAction SilentlyContinue) }}

    if (-not (Test-Cmd 'python')) {{
      Write-Host '==> Installing Python via winget...'
      if (Test-Cmd 'winget') {{
        winget install -e --id Python.Python.3.12 --silent --accept-source-agreements --accept-package-agreements
      }} else {{
        Write-Error 'winget not available; please install Python 3.12 first.'
        exit 1
      }}
    }}

    Write-Host '==> Fetching agent...'
    Invoke-WebRequest -UseBasicParsing -Uri "$RmmServer/install/agent.py" -OutFile (Join-Path $InstallDir 'agent.py')
    Invoke-WebRequest -UseBasicParsing -Uri "$RmmServer/install/agent-requirements.txt" -OutFile (Join-Path $InstallDir 'requirements.txt')

    Write-Host '==> Setting up venv...'
    Push-Location $InstallDir
    python -m venv venv
    & .\\venv\\Scripts\\python.exe -m pip install --upgrade pip
    & .\\venv\\Scripts\\python.exe -m pip install -r requirements.txt

    Set-Content -Path (Join-Path $InstallDir '.env') -Value @"
    RMM_SERVER=$RmmServer
    RMM_TOKEN=$RmmToken
    "@

    # Register as Windows service via NSSM-free approach: use a scheduled task at boot
    $taskName = 'CustomRMM Agent'
    schtasks /Delete /F /TN $taskName 2>$null | Out-Null

    $tr = "`"$InstallDir\\venv\\Scripts\\pythonw.exe`" `"$InstallDir\\agent.py`""
    schtasks /Create /F /SC ONSTART /RU SYSTEM /RL HIGHEST /TN $taskName /TR $tr | Out-Null
    schtasks /Run /TN $taskName | Out-Null

    Pop-Location
    Write-Host '==> Done. Agent registered as scheduled task "CustomRMM Agent".'
    """)


def render_server_install_sh(public_url: str) -> str:
    """Bash installer for the server itself (Linux + Docker)."""
    return dedent(f"""\
    #!/usr/bin/env bash
    # CustomRMM server installer (Linux + Docker)
    set -euo pipefail

    PUBLIC_URL="${{PUBLIC_URL:-{public_url}}}"

    if [[ "$EUID" -ne 0 ]]; then
      echo "Please run with sudo." >&2
      exit 1
    fi

    if ! command -v docker >/dev/null 2>&1; then
      echo "==> Installing Docker..."
      curl -fsSL https://get.docker.com | sh
    fi

    INSTALL_DIR=/opt/customrmm
    if [[ ! -d "$INSTALL_DIR" ]]; then
      echo "Run this from an unpacked customrmm/ directory, or copy the project to $INSTALL_DIR first." >&2
      exit 1
    fi
    cd "$INSTALL_DIR"

    if [[ ! -f .env ]]; then
      cp .env.example .env
      SECRET=$(python3 scripts/generate-secret.py)
      sed -i "s|^SECRET_KEY=.*|SECRET_KEY=$SECRET|" .env
      sed -i "s|^PUBLIC_URL=.*|PUBLIC_URL=$PUBLIC_URL|" .env
    fi

    docker compose up -d --build
    echo "==> Done. Open $PUBLIC_URL/setup-admin"
    """)


def render_server_install_ps1(public_url: str) -> str:
    """PowerShell installer for the server (Windows-native, no Docker)."""
    return dedent(f"""\
    # CustomRMM server installer (Windows)
    $ErrorActionPreference = 'Stop'

    if (-not [Security.Principal.WindowsPrincipal]::new(
            [Security.Principal.WindowsIdentity]::GetCurrent()
          ).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {{
      Write-Error 'Please run this script in an elevated (Administrator) PowerShell.'
      exit 1
    }}

    $PublicUrl = if ($env:PUBLIC_URL) {{ $env:PUBLIC_URL }} else {{ '{public_url}' }}

    function Test-Cmd($n) {{ [bool](Get-Command $n -ErrorAction SilentlyContinue) }}

    if (-not (Test-Cmd 'python')) {{
      if (Test-Cmd 'winget') {{
        winget install -e --id Python.Python.3.12 --silent --accept-source-agreements --accept-package-agreements
      }} else {{
        Write-Error 'Install Python 3.12 first.'
        exit 1
      }}
    }}

    if (-not (Test-Path .\\app\\main.py)) {{
      Write-Error 'Run this from the unpacked customrmm/ directory.'
      exit 1
    }}

    if (-not (Test-Path .\\.venv)) {{
      python -m venv .venv
    }}
    & .\\.venv\\Scripts\\python.exe -m pip install --upgrade pip
    & .\\.venv\\Scripts\\python.exe -m pip install -r requirements.txt

    if (-not (Test-Path .\\.env)) {{
      Copy-Item .\\.env.example .\\.env
      $secret = & .\\.venv\\Scripts\\python.exe .\\scripts\\generate-secret.py
      (Get-Content .\\.env) `
        -replace '^SECRET_KEY=.*', "SECRET_KEY=$secret" `
        -replace '^PUBLIC_URL=.*', "PUBLIC_URL=$PublicUrl" `
        | Set-Content .\\.env
    }}

    $taskName = 'CustomRMM Dashboard'
    schtasks /Delete /F /TN $taskName 2>$null | Out-Null
    $cwd = (Get-Location).Path
    $tr = "`"$cwd\\.venv\\Scripts\\python.exe`" -m uvicorn app.main:app --host 0.0.0.0 --port 8000"
    schtasks /Create /F /SC ONSTART /RU SYSTEM /RL HIGHEST /TN $taskName /TR $tr | Out-Null
    schtasks /Run /TN $taskName | Out-Null

    Write-Host "==> Done. Open $PublicUrl/setup-admin to finish setup."
    """)
