// Agent detail page: live metrics sparklines, command runner.

(function () {
  const agentId = window.AGENT_ID;
  if (!agentId) return;

  // -------- Tabs (reuse tabs.js logic inline) --------
  document.addEventListener('click', (e) => {
    const tab = e.target.closest('[data-tab]');
    if (!tab) return;
    const tabsRoot = tab.closest('[data-tabs]');
    if (!tabsRoot) return;
    const target = tab.dataset.tab;
    tabsRoot.querySelectorAll('[data-tab]').forEach(t => t.classList.toggle('active', t === tab));
    const scope = tabsRoot.parentElement;
    if (!scope) return;
    scope.querySelectorAll('[data-panel]').forEach(p => {
      p.classList.toggle('hidden', p.dataset.panel !== target);
    });
  });

  // -------- Sparklines --------
  function drawSpark(canvas, points) {
    const ctx = canvas.getContext('2d');
    const w = canvas.width, h = canvas.height;
    ctx.clearRect(0, 0, w, h);
    if (!points || points.length < 2) return;
    const max = 100;
    const stepX = w / (points.length - 1);

    // fill
    ctx.beginPath();
    points.forEach((v, i) => {
      const x = i * stepX, y = h - (v / max) * h;
      if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
    });
    ctx.lineTo(w, h); ctx.lineTo(0, h); ctx.closePath();
    ctx.fillStyle = 'rgba(110, 231, 135, 0.10)';
    ctx.fill();

    // stroke
    ctx.beginPath();
    points.forEach((v, i) => {
      const x = i * stepX, y = h - (v / max) * h;
      if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
    });
    ctx.strokeStyle = '#6ee787';
    ctx.lineWidth = 1.5;
    ctx.stroke();
  }

  async function refreshSparks() {
    try {
      const r = await fetch(`/api/dashboard/agents/${agentId}/metrics?minutes=60`);
      if (!r.ok) return;
      const d = await r.json();
      document.querySelectorAll('canvas[data-spark]').forEach(c => {
        const key = c.dataset.spark;
        drawSpark(c, d[key] || []);
      });
    } catch (e) { /* ignore */ }
  }
  refreshSparks();
  setInterval(refreshSparks, 30_000);

  // -------- Command runner --------
  const form = document.getElementById('cmd-form');
  const out = document.getElementById('cmd-output');
  if (!form || !out) return;

  async function pollCommand(cmdId) {
    for (let i = 0; i < 120; i++) { // up to ~6 minutes
      await new Promise(r => setTimeout(r, 3000));
      try {
        const r = await fetch(`/api/dashboard/agents/${agentId}/commands/${cmdId}`);
        if (!r.ok) continue;
        const d = await r.json();
        out.textContent = `[${d.status}] exit=${d.exit_code ?? '?'}\n` + (d.output || '');
        if (d.status === 'done' || d.status === 'error' || d.status === 'timeout') return;
      } catch (_) { /* continue */ }
    }
  }

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const fd = new FormData(form);
    out.textContent = `[queued] ${fd.get('payload')}`;
    const r = await fetch(`/api/dashboard/agents/${agentId}/run`, {
      method: 'POST', body: fd,
    });
    if (!r.ok) { out.textContent = '[error] failed to queue command'; return; }
    const d = await r.json();
    pollCommand(d.id);
  });

  const runScriptBtn = document.getElementById('run-script');
  if (runScriptBtn) {
    runScriptBtn.addEventListener('click', async () => {
      const sel = document.getElementById('script-select');
      if (!sel || !sel.value) return;
      const fd = new FormData();
      fd.append('script_id', sel.value);
      out.textContent = `[queued] script #${sel.value}`;
      const r = await fetch(`/api/dashboard/agents/${agentId}/run-script`, {
        method: 'POST', body: fd,
      });
      if (!r.ok) { out.textContent = '[error] failed to queue script'; return; }
      const d = await r.json();
      pollCommand(d.id);
    });
  }
})();
