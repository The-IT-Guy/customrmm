// Generic tab handler. Pairs [data-tabs] container with [data-panel] siblings.
document.addEventListener('click', (e) => {
  const tab = e.target.closest('[data-tab]');
  if (!tab) return;
  const tabsRoot = tab.closest('[data-tabs]');
  if (!tabsRoot) return;

  const target = tab.dataset.tab;
  // toggle tabs
  tabsRoot.querySelectorAll('[data-tab]').forEach(t => t.classList.toggle('active', t === tab));
  // toggle panels: look in the parent of tabsRoot for a sibling .tab-panels block
  const scope = tabsRoot.parentElement;
  if (!scope) return;
  scope.querySelectorAll('[data-panel]').forEach(p => {
    p.classList.toggle('hidden', p.dataset.panel !== target);
  });
});
