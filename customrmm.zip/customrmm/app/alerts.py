"""Threshold-based alert engine.

Runs as a background task. For each agent's latest snapshot, raises or
resolves alerts based on configured thresholds.
"""
from __future__ import annotations

import asyncio
import logging
from datetime import datetime, timedelta, timezone

from sqlalchemy import select, update

from .config import settings
from .db import AsyncSessionLocal
from .models import Agent, Alert


log = logging.getLogger("rmm.alerts")


async def _ensure_alert(db, agent: Agent, kind: str, level: str, title: str, detail: str) -> None:
    result = await db.execute(
        select(Alert).where(
            Alert.agent_id == agent.id,
            Alert.kind == kind,
            Alert.resolved_at.is_(None),
        )
    )
    existing = result.scalar_one_or_none()
    if existing:
        if existing.level != level or existing.detail != detail:
            existing.level = level
            existing.detail = detail
        return
    db.add(Alert(agent_id=agent.id, kind=kind, level=level, title=title, detail=detail))


async def _resolve_alert(db, agent: Agent, kind: str) -> None:
    await db.execute(
        update(Alert)
        .where(Alert.agent_id == agent.id, Alert.kind == kind, Alert.resolved_at.is_(None))
        .values(resolved_at=datetime.now(timezone.utc))
    )


def _level_for(value: float, warn: float, crit: float) -> str | None:
    if value >= crit:
        return "critical"
    if value >= warn:
        return "warning"
    return None


async def evaluate_once() -> None:
    async with AsyncSessionLocal() as db:
        agents = (await db.execute(select(Agent))).scalars().all()
        now = datetime.now(timezone.utc)
        offline_cutoff = now - timedelta(seconds=settings.offline_after_seconds)

        for agent in agents:
            # offline alert
            is_offline = (agent.last_seen is None) or (agent.last_seen < offline_cutoff)
            if is_offline:
                if agent.online:
                    agent.online = False
                await _ensure_alert(
                    db, agent, "offline", "warning",
                    f"{agent.hostname or agent.agent_id} is offline",
                    f"No checkin since {agent.last_seen.isoformat() if agent.last_seen else 'never'}",
                )
            else:
                await _resolve_alert(db, agent, "offline")

                # threshold alerts only meaningful when online
                for metric, warn, crit, kind, label in [
                    (agent.cpu_pct,  settings.cpu_warn,  settings.cpu_crit,  "cpu",  "CPU"),
                    (agent.mem_pct,  settings.mem_warn,  settings.mem_crit,  "mem",  "Memory"),
                    (agent.disk_pct, settings.disk_warn, settings.disk_crit, "disk", "Disk"),
                ]:
                    lvl = _level_for(metric, warn, crit)
                    if lvl:
                        await _ensure_alert(
                            db, agent, kind, lvl,
                            f"{label} high on {agent.hostname or agent.agent_id}",
                            f"{label} at {metric:.1f}% (warn {warn}%, crit {crit}%)",
                        )
                    else:
                        await _resolve_alert(db, agent, kind)

        await db.commit()


async def alert_loop(interval: int = 30) -> None:
    while True:
        try:
            await evaluate_once()
        except Exception as e:  # noqa: BLE001
            log.warning("alert evaluation failed: %s", e)
        await asyncio.sleep(interval)
