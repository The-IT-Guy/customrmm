"""ORM models. All models inherit from Base."""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Optional

from sqlalchemy import (
    Boolean,
    DateTime,
    Float,
    ForeignKey,
    Index,
    Integer,
    String,
    Text,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from .db import Base


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


class User(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    username: Mapped[str] = mapped_column(String(64), unique=True, index=True)
    password_hash: Mapped[str] = mapped_column(String(255))
    is_admin: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)


class EnrollmentToken(Base):
    """A token used to enroll new agents."""
    __tablename__ = "enrollment_tokens"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    token: Mapped[str] = mapped_column(String(64), unique=True, index=True)
    label: Mapped[str] = mapped_column(String(120), default="default")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)
    revoked: Mapped[bool] = mapped_column(Boolean, default=False)


class Agent(Base):
    __tablename__ = "agents"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    agent_id: Mapped[str] = mapped_column(String(64), unique=True, index=True)
    auth_token: Mapped[str] = mapped_column(String(128), unique=True, index=True)

    hostname: Mapped[str] = mapped_column(String(255), default="")
    os_family: Mapped[str] = mapped_column(String(32), default="")  # windows | linux | darwin
    os_version: Mapped[str] = mapped_column(String(255), default="")
    arch: Mapped[str] = mapped_column(String(32), default="")
    agent_version: Mapped[str] = mapped_column(String(32), default="")
    public_ip: Mapped[str] = mapped_column(String(64), default="")
    private_ip: Mapped[str] = mapped_column(String(64), default="")

    online: Mapped[bool] = mapped_column(Boolean, default=False, index=True)
    last_seen: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True, index=True)
    enrolled_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)

    # Latest snapshot (denormalized for quick lists)
    cpu_pct: Mapped[float] = mapped_column(Float, default=0.0)
    mem_pct: Mapped[float] = mapped_column(Float, default=0.0)
    disk_pct: Mapped[float] = mapped_column(Float, default=0.0)
    uptime_seconds: Mapped[int] = mapped_column(Integer, default=0)

    metrics: Mapped[list["Metric"]] = relationship(back_populates="agent", cascade="all, delete-orphan")
    events: Mapped[list["AgentEvent"]] = relationship(back_populates="agent", cascade="all, delete-orphan")
    commands: Mapped[list["Command"]] = relationship(back_populates="agent", cascade="all, delete-orphan")
    alerts: Mapped[list["Alert"]] = relationship(back_populates="agent", cascade="all, delete-orphan")
    software: Mapped[list["SoftwareItem"]] = relationship(back_populates="agent", cascade="all, delete-orphan")
    patches: Mapped[list["PatchItem"]] = relationship(back_populates="agent", cascade="all, delete-orphan")


class Metric(Base):
    """A point-in-time metric snapshot from an agent."""
    __tablename__ = "metrics"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    agent_id: Mapped[int] = mapped_column(ForeignKey("agents.id"), index=True)
    ts: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow, index=True)
    cpu_pct: Mapped[float] = mapped_column(Float, default=0.0)
    mem_pct: Mapped[float] = mapped_column(Float, default=0.0)
    disk_pct: Mapped[float] = mapped_column(Float, default=0.0)
    net_rx_bps: Mapped[float] = mapped_column(Float, default=0.0)
    net_tx_bps: Mapped[float] = mapped_column(Float, default=0.0)
    load_1m: Mapped[float] = mapped_column(Float, default=0.0)

    agent: Mapped["Agent"] = relationship(back_populates="metrics")


class AgentEvent(Base):
    """OS event log items / general agent events."""
    __tablename__ = "agent_events"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    agent_id: Mapped[int] = mapped_column(ForeignKey("agents.id"), index=True)
    ts: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow, index=True)
    source: Mapped[str] = mapped_column(String(64), default="")  # system | application | agent
    level: Mapped[str] = mapped_column(String(16), default="info")  # info | warning | error | critical
    code: Mapped[str] = mapped_column(String(64), default="")
    message: Mapped[str] = mapped_column(Text, default="")

    agent: Mapped["Agent"] = relationship(back_populates="events")


class SoftwareItem(Base):
    __tablename__ = "software_items"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    agent_id: Mapped[int] = mapped_column(ForeignKey("agents.id"), index=True)
    name: Mapped[str] = mapped_column(String(255), default="", index=True)
    version: Mapped[str] = mapped_column(String(120), default="")
    publisher: Mapped[str] = mapped_column(String(255), default="")
    install_date: Mapped[str] = mapped_column(String(64), default="")

    agent: Mapped["Agent"] = relationship(back_populates="software")


class PatchItem(Base):
    __tablename__ = "patch_items"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    agent_id: Mapped[int] = mapped_column(ForeignKey("agents.id"), index=True)
    name: Mapped[str] = mapped_column(String(255), default="")
    kb: Mapped[str] = mapped_column(String(64), default="")
    severity: Mapped[str] = mapped_column(String(32), default="")
    available: Mapped[bool] = mapped_column(Boolean, default=True)

    agent: Mapped["Agent"] = relationship(back_populates="patches")


class Command(Base):
    """Remote command queued for an agent."""
    __tablename__ = "commands"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    agent_id: Mapped[int] = mapped_column(ForeignKey("agents.id"), index=True)
    kind: Mapped[str] = mapped_column(String(32), default="shell")   # shell | script | builtin
    shell: Mapped[str] = mapped_column(String(32), default="auto")    # auto | powershell | cmd | bash | sh
    payload: Mapped[str] = mapped_column(Text, default="")
    status: Mapped[str] = mapped_column(String(16), default="queued")  # queued | running | done | error | timeout
    output: Mapped[str] = mapped_column(Text, default="")
    exit_code: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)
    started_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    finished_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)

    agent: Mapped["Agent"] = relationship(back_populates="commands")


class Script(Base):
    """A reusable script in the script library."""
    __tablename__ = "scripts"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(255), unique=True)
    description: Mapped[str] = mapped_column(Text, default="")
    shell: Mapped[str] = mapped_column(String(32), default="bash")    # powershell | bash | sh | python
    body: Mapped[str] = mapped_column(Text, default="")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)


class Alert(Base):
    __tablename__ = "alerts"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    agent_id: Mapped[int] = mapped_column(ForeignKey("agents.id"), index=True)
    level: Mapped[str] = mapped_column(String(16), default="warning")  # warning | critical | info
    kind: Mapped[str] = mapped_column(String(32), default="threshold")
    title: Mapped[str] = mapped_column(String(255), default="")
    detail: Mapped[str] = mapped_column(Text, default="")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow, index=True)
    resolved_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)

    agent: Mapped["Agent"] = relationship(back_populates="alerts")


Index("ix_metric_agent_ts", Metric.agent_id, Metric.ts.desc())
Index("ix_event_agent_ts", AgentEvent.agent_id, AgentEvent.ts.desc())
