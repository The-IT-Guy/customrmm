"""WebSocket connection registry.

Tracks live agent connections (by agent_id) and dashboard connections.
Allows the dashboard to push commands directly to a connected agent
when the WS is up, falling back to HTTP polling when not.
"""
from __future__ import annotations

import asyncio
import json
from typing import Dict, Set

from fastapi import WebSocket


class WsRegistry:
    def __init__(self) -> None:
        self.agents: Dict[str, WebSocket] = {}
        self.dashboards: Set[WebSocket] = set()
        self._lock = asyncio.Lock()

    async def add_agent(self, agent_id: str, ws: WebSocket) -> None:
        async with self._lock:
            # Replace any prior connection for this agent
            old = self.agents.get(agent_id)
            if old is not None and old is not ws:
                try:
                    await old.close()
                except Exception:
                    pass
            self.agents[agent_id] = ws

    async def remove_agent(self, agent_id: str, ws: WebSocket) -> None:
        async with self._lock:
            cur = self.agents.get(agent_id)
            if cur is ws:
                self.agents.pop(agent_id, None)

    def is_online(self, agent_id: str) -> bool:
        return agent_id in self.agents

    async def send_to_agent(self, agent_id: str, msg: dict) -> bool:
        ws = self.agents.get(agent_id)
        if ws is None:
            return False
        try:
            await ws.send_text(json.dumps(msg))
            return True
        except Exception:
            return False

    async def add_dashboard(self, ws: WebSocket) -> None:
        async with self._lock:
            self.dashboards.add(ws)

    async def remove_dashboard(self, ws: WebSocket) -> None:
        async with self._lock:
            self.dashboards.discard(ws)

    async def broadcast_dashboard(self, msg: dict) -> None:
        if not self.dashboards:
            return
        dead = []
        text = json.dumps(msg)
        for ws in list(self.dashboards):
            try:
                await ws.send_text(text)
            except Exception:
                dead.append(ws)
        for ws in dead:
            self.dashboards.discard(ws)


registry = WsRegistry()
