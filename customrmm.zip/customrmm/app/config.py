"""Application configuration. Reads from environment / .env file.

Cross-platform: all paths use pathlib so the server runs identically
on Linux and Windows.
"""
from __future__ import annotations

import secrets
from pathlib import Path

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


# Project root is one level above /app
BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
DATA_DIR.mkdir(exist_ok=True)


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=str(BASE_DIR / ".env"),
        env_file_encoding="utf-8",
        extra="ignore",
    )

    # Server
    host: str = "0.0.0.0"
    port: int = 8000
    public_url: str = "http://localhost:8000"

    # Security
    secret_key: str = Field(default_factory=lambda: secrets.token_urlsafe(64))
    session_cookie: str = "rmm_session"
    session_max_age: int = 60 * 60 * 24 * 7  # 7 days

    # Database (SQLite path is cross-platform via pathlib)
    database_url: str = f"sqlite+aiosqlite:///{(DATA_DIR / 'rmm.db').as_posix()}"

    # Agents
    offline_after_seconds: int = 120
    metric_retention_hours: int = 168   # keep 1 week
    event_retention_count: int = 500    # per agent

    # Alerts (default thresholds, percent)
    cpu_warn: float = 85.0
    cpu_crit: float = 95.0
    mem_warn: float = 85.0
    mem_crit: float = 95.0
    disk_warn: float = 85.0
    disk_crit: float = 95.0


settings = Settings()
