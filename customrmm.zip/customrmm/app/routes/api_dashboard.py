"""Dashboard-facing API endpoints (called from the UI / HTMX)."""
from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone

from fastapi import APIRouter, Depends, Form, HTTPException
from fastapi.responses import JSONResponse
from sqlalchemy import desc, select
from sqlalchemy.ext.asyncio import AsyncSession

from ..auth import require_user
from ..db import get_session
from ..models import Agent, Command, Metric, Script, User
from ..ws import registry


router = APIRouter(prefix="/api/dashboard", tags=["dashboard"])


def _shell_for(agent: Agent, requested: str) -> str:
    if requested and requested != "auto":
        return requested
    if agent.os_family == "windows":
        return "powershell"
    return "bash"


@router.post("/agents/{agent_id}/run")
async def run_command(
    agent_id: str,
    payload: str = Form(...),
    shell: str = Form("auto"),
    db: AsyncSession = Depends(get_session),
    user: User = Depends(require_user),
):
    agent = (await db.execute(select(Agent).where(Agent.agent_id == agent_id))).scalar_one_or_none()
    if not agent:
        raise HTTPException(404)
    cmd = Command(
        agent_id=agent.id, kind="shell",
        shell=_shell_for(agent, shell), payload=payload, status="queued",
    )
    db.add(cmd)
    await db.commit()
    await db.refresh(cmd)

    # If WS is connected, push immediately
    if registry.is_online(agent.agent_id):
        await registry.send_to_agent(agent.agent_id, {
            "type": "command",
            "id": cmd.id,
            "shell": cmd.shell,
            "payload": cmd.payload,
        })
        cmd.status = "running"
        cmd.started_at = datetime.now(timezone.utc)
        await db.commit()

    return JSONResponse({"id": cmd.id, "status": cmd.status})


@router.post("/agents/{agent_id}/run-script")
async def run_script(
    agent_id: str,
    script_id: int = Form(...),
    db: AsyncSession = Depends(get_session),
    user: User = Depends(require_user),
):
    agent = (await db.execute(select(Agent).where(Agent.agent_id == agent_id))).scalar_one_or_none()
    if not agent:
        raise HTTPException(404, "agent not found")
    script = (await db.execute(select(Script).where(Script.id == script_id))).scalar_one_or_none()
    if not script:
        raise HTTPException(404, "script not found")

    cmd = Command(
        agent_id=agent.id, kind="script",
        shell=script.shell, payload=script.body, status="queued",
    )
    db.add(cmd)
    await db.commit()
    await db.refresh(cmd)

    if registry.is_online(agent.agent_id):
        await registry.send_to_agent(agent.agent_id, {
            "type": "command",
            "id": cmd.id,
            "shell": cmd.shell,
            "payload": cmd.payload,
        })
        cmd.status = "running"
        cmd.started_at = datetime.now(timezone.utc)
        await db.commit()

    return JSONResponse({"id": cmd.id, "status": cmd.status})


@router.get("/agents/{agent_id}/commands/{cmd_id}")
async def command_status(
    agent_id: str, cmd_id: int,
    db: AsyncSession = Depends(get_session),
    user: User = Depends(require_user),
):
    cmd = (await db.execute(
        select(Command).join(Agent, Command.agent_id == Agent.id)
        .where(Command.id == cmd_id, Agent.agent_id == agent_id)
    )).scalar_one_or_none()
    if not cmd:
        raise HTTPException(404)
    return {
        "id": cmd.id,
        "status": cmd.status,
        "exit_code": cmd.exit_code,
        "output": cmd.output,
        "started_at": cmd.started_at.isoformat() if cmd.started_at else None,
        "finished_at": cmd.finished_at.isoformat() if cmd.finished_at else None,
    }


@router.get("/agents/{agent_id}/metrics")
async def metrics_for_agent(
    agent_id: str,
    minutes: int = 60,
    db: AsyncSession = Depends(get_session),
    user: User = Depends(require_user),
):
    agent = (await db.execute(select(Agent).where(Agent.agent_id == agent_id))).scalar_one_or_none()
    if not agent:
        raise HTTPException(404)
    since = datetime.now(timezone.utc) - timedelta(minutes=max(1, min(minutes, 24 * 60)))
    rows = (await db.execute(
        select(Metric).where(Metric.agent_id == agent.id, Metric.ts >= since)
        .order_by(Metric.ts)
    )).scalars().all()
    return {
        "ts": [m.ts.isoformat() for m in rows],
        "cpu": [m.cpu_pct for m in rows],
        "mem": [m.mem_pct for m in rows],
        "disk": [m.disk_pct for m in rows],
    }
