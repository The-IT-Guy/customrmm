"""Install endpoints - serve the agent payload + personalized installer scripts.

These endpoints are intentionally unauthenticated so the one-liner install
flow can fetch them. Risk is limited because:
- The agent itself enrolls with a token (which we DO require).
- agent.py + requirements.txt are public artifacts anyway.
"""
from __future__ import annotations

from pathlib import Path

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import PlainTextResponse, Response
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from ..config import settings
from ..db import get_session
from ..installers import (
    render_agent_ps1, render_agent_sh,
    render_server_install_ps1, render_server_install_sh,
)
from ..models import EnrollmentToken


router = APIRouter(prefix="/install", tags=["install"])


_AGENT_PY_PATH = Path(__file__).resolve().parent.parent.parent / "agent" / "customrmm_agent.py"
_AGENT_REQ_PATH = Path(__file__).resolve().parent.parent.parent / "agent" / "requirements.txt"


@router.get("/agent.py", response_class=PlainTextResponse)
async def agent_py():
    if not _AGENT_PY_PATH.exists():
        raise HTTPException(500, "agent.py missing on server")
    return PlainTextResponse(_AGENT_PY_PATH.read_text(encoding="utf-8"), media_type="text/x-python")


@router.get("/agent-requirements.txt", response_class=PlainTextResponse)
async def agent_requirements():
    if not _AGENT_REQ_PATH.exists():
        raise HTTPException(500, "requirements.txt missing on server")
    return PlainTextResponse(_AGENT_REQ_PATH.read_text(encoding="utf-8"), media_type="text/plain")


async def _resolve_token(token: str | None, db: AsyncSession) -> str:
    if token:
        return token
    tok = (await db.execute(
        select(EnrollmentToken).where(EnrollmentToken.revoked.is_(False))
        .order_by(EnrollmentToken.created_at.desc()).limit(1)
    )).scalar_one_or_none()
    if not tok:
        raise HTTPException(400, "no active enrollment token; create one in /install")
    return tok.token


@router.get("/agent.sh", response_class=PlainTextResponse)
async def agent_sh(
    token: str | None = Query(default=None),
    db: AsyncSession = Depends(get_session),
):
    tok = await _resolve_token(token, db)
    body = render_agent_sh(settings.public_url, tok)
    return PlainTextResponse(body, media_type="text/x-shellscript")


@router.get("/agent.ps1", response_class=PlainTextResponse)
async def agent_ps1(
    token: str | None = Query(default=None),
    db: AsyncSession = Depends(get_session),
):
    tok = await _resolve_token(token, db)
    body = render_agent_ps1(settings.public_url, tok)
    return PlainTextResponse(body, media_type="text/plain")


@router.get("/server.sh", response_class=PlainTextResponse)
async def server_sh():
    return PlainTextResponse(render_server_install_sh(settings.public_url),
                             media_type="text/x-shellscript")


@router.get("/server.ps1", response_class=PlainTextResponse)
async def server_ps1():
    return PlainTextResponse(render_server_install_ps1(settings.public_url),
                             media_type="text/plain")
