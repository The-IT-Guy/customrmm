"""Agent-facing API endpoints.

Auth model:
- /agent/enroll uses an enrollment token (reusable until revoked - simple for v1).
- All others use the per-agent bearer token returned at enrollment.
"""
from __future__ import annotations

from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy import delete, select
from sqlalchemy.ext.asyncio import AsyncSession

from ..auth import require_agent
from ..config import settings
from ..db import get_session
from ..models import (
    Agent, AgentEvent, Command, EnrollmentToken, Metric, PatchItem, SoftwareItem,
)
from ..schemas import (
    CheckinRequest, CheckinResponse, CommandPayload, CommandResult,
    EnrollRequest, EnrollResponse, InventoryPayload,
)
from ..security import gen_token


router = APIRouter(prefix="/api/agent", tags=["agent"])


@router.post("/enroll", response_model=EnrollResponse)
async def enroll(req: EnrollRequest, request: Request, db: AsyncSession = Depends(get_session)):
    tok = (await db.execute(
        select(EnrollmentToken).where(
            EnrollmentToken.token == req.enrollment_token,
            EnrollmentToken.revoked.is_(False),
        )
    )).scalar_one_or_none()
    if not tok:
        raise HTTPException(status_code=401, detail="invalid enrollment token")

    public_ip = (request.client.host if request.client else "") or ""
    agent = Agent(
        agent_id=gen_token(12),
        auth_token=gen_token(32),
        hostname=req.hostname,
        os_family=req.os_family.lower(),
        os_version=req.os_version,
        arch=req.arch,
        agent_version=req.agent_version,
        private_ip=req.private_ip,
        public_ip=public_ip,
        last_seen=datetime.now(timezone.utc),
        online=True,
    )
    db.add(agent)
    await db.commit()
    await db.refresh(agent)

    ws_url = settings.public_url.rstrip("/").replace("http://", "ws://").replace("https://", "wss://") + "/ws/agent"

    return EnrollResponse(
        agent_id=agent.agent_id,
        auth_token=agent.auth_token,
        websocket_url=ws_url,
        poll_interval_seconds=30,
    )


@router.post("/checkin", response_model=CheckinResponse)
async def checkin(
    payload: CheckinRequest,
    db: AsyncSession = Depends(get_session),
    agent: Agent = Depends(require_agent),
):
    now = datetime.now(timezone.utc)
    agent.last_seen = now
    agent.online = True
    agent.cpu_pct = payload.cpu_pct
    agent.mem_pct = payload.mem_pct
    agent.disk_pct = payload.disk_pct
    agent.uptime_seconds = payload.uptime_seconds

    db.add(Metric(
        agent_id=agent.id, ts=now,
        cpu_pct=payload.cpu_pct, mem_pct=payload.mem_pct, disk_pct=payload.disk_pct,
        net_rx_bps=payload.net_rx_bps, net_tx_bps=payload.net_tx_bps, load_1m=payload.load_1m,
    ))

    pending = (await db.execute(
        select(Command).where(Command.agent_id == agent.id, Command.status == "queued")
        .order_by(Command.created_at).limit(20)
    )).scalars().all()
    for c in pending:
        c.status = "running"
        c.started_at = now

    await db.commit()

    return CheckinResponse(
        pending_commands=[
            CommandPayload(id=c.id, kind=c.kind, shell=c.shell, payload=c.payload)
            for c in pending
        ],
        inventory_due=False,  # client decides cadence; server can request via WS later
    )


@router.post("/command-result")
async def command_result(
    result: CommandResult,
    db: AsyncSession = Depends(get_session),
    agent: Agent = Depends(require_agent),
):
    cmd = (await db.execute(
        select(Command).where(Command.id == result.id, Command.agent_id == agent.id)
    )).scalar_one_or_none()
    if not cmd:
        raise HTTPException(status_code=404, detail="command not found")
    cmd.status = result.status
    cmd.output = (result.output or "")[:200_000]
    cmd.exit_code = result.exit_code
    cmd.finished_at = datetime.now(timezone.utc)
    await db.commit()
    return {"ok": True}


@router.post("/inventory")
async def inventory(
    payload: InventoryPayload,
    db: AsyncSession = Depends(get_session),
    agent: Agent = Depends(require_agent),
):
    # Replace software + patches snapshot
    await db.execute(delete(SoftwareItem).where(SoftwareItem.agent_id == agent.id))
    await db.execute(delete(PatchItem).where(PatchItem.agent_id == agent.id))

    for item in payload.software[:5000]:
        db.add(SoftwareItem(
            agent_id=agent.id, name=item.name[:255], version=item.version[:120],
            publisher=item.publisher[:255], install_date=item.install_date[:64],
        ))
    for item in payload.patches[:2000]:
        db.add(PatchItem(
            agent_id=agent.id, name=item.name[:255], kb=item.kb[:64],
            severity=item.severity[:32], available=item.available,
        ))

    # Append events (capped)
    for ev in payload.events[:settings.event_retention_count]:
        db.add(AgentEvent(
            agent_id=agent.id,
            ts=ev.ts or datetime.now(timezone.utc),
            source=ev.source[:64], level=ev.level[:16],
            code=ev.code[:64], message=ev.message[:4000],
        ))

    await db.commit()
    return {"ok": True}
