"""HTML page routes (Jinja-rendered)."""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
from pathlib import Path

from fastapi import APIRouter, Depends, Form, HTTPException, Request, status
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from sqlalchemy import desc, func, select
from sqlalchemy.ext.asyncio import AsyncSession

from ..auth import current_user, require_user
from ..config import settings
from ..db import get_session
from ..models import (
    Agent, Alert, AgentEvent, Command, EnrollmentToken, PatchItem, Script,
    SoftwareItem, User,
)
from ..security import gen_token, hash_password, verify_password


TEMPLATES = Jinja2Templates(directory=str(Path(__file__).resolve().parent.parent / "templates"))
router = APIRouter()


# ---------- Setup / login ----------

@router.get("/", response_class=HTMLResponse)
async def root(request: Request, db: AsyncSession = Depends(get_session)):
    has_admin = (await db.execute(select(func.count(User.id)))).scalar_one() > 0
    if not has_admin:
        return RedirectResponse(url="/setup-admin", status_code=302)
    if not request.session.get("user_id"):
        return RedirectResponse(url="/login", status_code=302)
    return RedirectResponse(url="/dashboard", status_code=302)


@router.get("/setup-admin", response_class=HTMLResponse)
async def setup_admin_get(request: Request, db: AsyncSession = Depends(get_session)):
    has_admin = (await db.execute(select(func.count(User.id)))).scalar_one() > 0
    if has_admin:
        return RedirectResponse(url="/login", status_code=302)
    return TEMPLATES.TemplateResponse("setup_admin.html", {"request": request})


@router.post("/setup-admin")
async def setup_admin_post(
    request: Request,
    username: str = Form(...),
    password: str = Form(...),
    confirm: str = Form(...),
    db: AsyncSession = Depends(get_session),
):
    has_admin = (await db.execute(select(func.count(User.id)))).scalar_one() > 0
    if has_admin:
        return RedirectResponse(url="/login", status_code=302)
    if password != confirm or len(password) < 8:
        return TEMPLATES.TemplateResponse(
            "setup_admin.html",
            {"request": request, "error": "Passwords must match and be at least 8 characters."},
            status_code=400,
        )
    user = User(username=username.strip(), password_hash=hash_password(password), is_admin=True)
    db.add(user)

    # Seed the first enrollment token
    db.add(EnrollmentToken(token=gen_token(24), label="default"))
    await db.commit()

    request.session["user_id"] = user.id
    return RedirectResponse(url="/dashboard", status_code=302)


@router.get("/login", response_class=HTMLResponse)
async def login_get(request: Request):
    return TEMPLATES.TemplateResponse("login.html", {"request": request})


@router.post("/login")
async def login_post(
    request: Request,
    username: str = Form(...),
    password: str = Form(...),
    db: AsyncSession = Depends(get_session),
):
    user = (await db.execute(select(User).where(User.username == username.strip()))).scalar_one_or_none()
    if not user or not verify_password(password, user.password_hash):
        return TEMPLATES.TemplateResponse(
            "login.html",
            {"request": request, "error": "Invalid credentials."},
            status_code=401,
        )
    request.session["user_id"] = user.id
    return RedirectResponse(url="/dashboard", status_code=302)


@router.post("/logout")
async def logout(request: Request):
    request.session.clear()
    return RedirectResponse(url="/login", status_code=302)


# ---------- Dashboard pages ----------

@router.get("/dashboard", response_class=HTMLResponse)
async def dashboard(
    request: Request,
    db: AsyncSession = Depends(get_session),
    user: User = Depends(require_user),
):
    total = (await db.execute(select(func.count(Agent.id)))).scalar_one()
    online = (await db.execute(select(func.count(Agent.id)).where(Agent.online.is_(True)))).scalar_one()
    open_alerts_q = select(func.count(Alert.id)).where(Alert.resolved_at.is_(None))
    open_alerts = (await db.execute(open_alerts_q)).scalar_one()
    crit_q = select(func.count(Alert.id)).where(Alert.resolved_at.is_(None), Alert.level == "critical")
    crit = (await db.execute(crit_q)).scalar_one()

    alert_rows = (
        await db.execute(
            select(Alert, Agent)
            .join(Agent, Alert.agent_id == Agent.id)
            .where(Alert.resolved_at.is_(None))
            .order_by(desc(Alert.created_at))
            .limit(20)
        )
    ).all()

    return TEMPLATES.TemplateResponse(
        "dashboard.html",
        {
            "request": request, "user": user,
            "total": total, "online": online,
            "open_alerts": open_alerts, "crit": crit,
            "alerts": alert_rows,
        },
    )


@router.get("/agents", response_class=HTMLResponse)
async def agents_list(
    request: Request,
    q: str = "",
    db: AsyncSession = Depends(get_session),
    user: User = Depends(require_user),
):
    stmt = select(Agent)
    if q:
        like = f"%{q.strip()}%"
        stmt = stmt.where(Agent.hostname.ilike(like))
    stmt = stmt.order_by(desc(Agent.online), Agent.hostname)
    agents = (await db.execute(stmt)).scalars().all()
    return TEMPLATES.TemplateResponse(
        "agents_list.html",
        {"request": request, "user": user, "agents": agents, "q": q},
    )


@router.get("/agents/{agent_id}", response_class=HTMLResponse)
async def agent_detail(
    agent_id: str,
    request: Request,
    db: AsyncSession = Depends(get_session),
    user: User = Depends(require_user),
):
    agent = (await db.execute(select(Agent).where(Agent.agent_id == agent_id))).scalar_one_or_none()
    if not agent:
        raise HTTPException(404)

    recent_events = (
        await db.execute(
            select(AgentEvent).where(AgentEvent.agent_id == agent.id)
            .order_by(desc(AgentEvent.ts)).limit(50)
        )
    ).scalars().all()
    recent_commands = (
        await db.execute(
            select(Command).where(Command.agent_id == agent.id)
            .order_by(desc(Command.created_at)).limit(20)
        )
    ).scalars().all()
    software = (
        await db.execute(
            select(SoftwareItem).where(SoftwareItem.agent_id == agent.id)
            .order_by(SoftwareItem.name).limit(500)
        )
    ).scalars().all()
    patches = (
        await db.execute(
            select(PatchItem).where(PatchItem.agent_id == agent.id, PatchItem.available.is_(True))
            .order_by(PatchItem.severity, PatchItem.name).limit(500)
        )
    ).scalars().all()
    open_alerts = (
        await db.execute(
            select(Alert).where(Alert.agent_id == agent.id, Alert.resolved_at.is_(None))
            .order_by(desc(Alert.created_at))
        )
    ).scalars().all()
    scripts = (await db.execute(select(Script).order_by(Script.name))).scalars().all()

    return TEMPLATES.TemplateResponse(
        "agent_detail.html",
        {
            "request": request, "user": user, "agent": agent,
            "events": recent_events, "commands": recent_commands,
            "software": software, "patches": patches,
            "open_alerts": open_alerts, "scripts": scripts,
        },
    )


@router.get("/alerts", response_class=HTMLResponse)
async def alerts_page(
    request: Request,
    db: AsyncSession = Depends(get_session),
    user: User = Depends(require_user),
):
    rows = (
        await db.execute(
            select(Alert, Agent).join(Agent, Alert.agent_id == Agent.id)
            .order_by(Alert.resolved_at.is_not(None), desc(Alert.created_at))
            .limit(200)
        )
    ).all()
    return TEMPLATES.TemplateResponse(
        "alerts.html", {"request": request, "user": user, "rows": rows},
    )


@router.get("/scripts", response_class=HTMLResponse)
async def scripts_page(
    request: Request,
    db: AsyncSession = Depends(get_session),
    user: User = Depends(require_user),
):
    scripts = (await db.execute(select(Script).order_by(Script.name))).scalars().all()
    return TEMPLATES.TemplateResponse(
        "scripts.html", {"request": request, "user": user, "scripts": scripts},
    )


@router.post("/scripts")
async def scripts_create(
    request: Request,
    name: str = Form(...),
    description: str = Form(""),
    shell: str = Form("bash"),
    body: str = Form(...),
    db: AsyncSession = Depends(get_session),
    user: User = Depends(require_user),
):
    db.add(Script(name=name.strip(), description=description, shell=shell, body=body))
    await db.commit()
    return RedirectResponse(url="/scripts", status_code=302)


@router.post("/scripts/{script_id}/delete")
async def scripts_delete(
    script_id: int,
    db: AsyncSession = Depends(get_session),
    user: User = Depends(require_user),
):
    script = (await db.execute(select(Script).where(Script.id == script_id))).scalar_one_or_none()
    if script:
        await db.delete(script)
        await db.commit()
    return RedirectResponse(url="/scripts", status_code=302)


@router.get("/install", response_class=HTMLResponse)
async def install_page(
    request: Request,
    db: AsyncSession = Depends(get_session),
    user: User = Depends(require_user),
):
    tokens = (await db.execute(select(EnrollmentToken).order_by(desc(EnrollmentToken.created_at)))).scalars().all()
    if not tokens:
        tok = EnrollmentToken(token=gen_token(24), label="default")
        db.add(tok)
        await db.commit()
        tokens = [tok]
    active = next((t for t in tokens if not t.revoked), tokens[0])
    return TEMPLATES.TemplateResponse(
        "install.html",
        {
            "request": request, "user": user,
            "tokens": tokens, "active_token": active.token,
            "public_url": settings.public_url,
        },
    )


@router.post("/install/tokens")
async def install_create_token(
    label: str = Form("token"),
    db: AsyncSession = Depends(get_session),
    user: User = Depends(require_user),
):
    db.add(EnrollmentToken(token=gen_token(24), label=label.strip() or "token"))
    await db.commit()
    return RedirectResponse(url="/install", status_code=302)


@router.post("/install/tokens/{token_id}/revoke")
async def install_revoke_token(
    token_id: int,
    db: AsyncSession = Depends(get_session),
    user: User = Depends(require_user),
):
    tok = (await db.execute(select(EnrollmentToken).where(EnrollmentToken.id == token_id))).scalar_one_or_none()
    if tok:
        tok.revoked = True
        await db.commit()
    return RedirectResponse(url="/install", status_code=302)
