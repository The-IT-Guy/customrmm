"""Auth dependencies - session for users, bearer for agents."""
from __future__ import annotations

from typing import Optional

from fastapi import Depends, HTTPException, Request, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from .db import get_session
from .models import Agent, User


async def current_user(
    request: Request,
    db: AsyncSession = Depends(get_session),
) -> Optional[User]:
    user_id = request.session.get("user_id")
    if not user_id:
        return None
    result = await db.execute(select(User).where(User.id == user_id))
    return result.scalar_one_or_none()


async def require_user(
    user: Optional[User] = Depends(current_user),
) -> User:
    if user is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="auth required")
    return user


async def require_agent(
    request: Request,
    db: AsyncSession = Depends(get_session),
) -> Agent:
    """Authenticate an agent via Authorization: Bearer <token>."""
    auth = request.headers.get("authorization", "")
    if not auth.lower().startswith("bearer "):
        raise HTTPException(status_code=401, detail="missing bearer token")
    token = auth.split(" ", 1)[1].strip()
    result = await db.execute(select(Agent).where(Agent.auth_token == token))
    agent = result.scalar_one_or_none()
    if not agent:
        raise HTTPException(status_code=401, detail="invalid agent token")
    return agent
