# CustomRMM agent installer (Windows) - standalone version.
# Use the dashboard's /install page for a personalized one-liner.
$ErrorActionPreference = 'Stop'

if (-not [Security.Principal.WindowsPrincipal]::new(
        [Security.Principal.WindowsIdentity]::GetCurrent()
      ).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
  Write-Error 'Please run this script in an elevated (Administrator) PowerShell.'
  exit 1
}

if (-not $env:RMM_SERVER -or -not $env:RMM_TOKEN) {
  Write-Error "Set `$env:RMM_SERVER and `$env:RMM_TOKEN before running this script."
  exit 1
}

$RmmServer = $env:RMM_SERVER
$RmmToken  = $env:RMM_TOKEN

$InstallDir = 'C:\Program Files\CustomRMM'
New-Item -ItemType Directory -Force -Path $InstallDir | Out-Null

function Test-Cmd($name) { [bool](Get-Command $name -ErrorAction SilentlyContinue) }

if (-not (Test-Cmd 'python')) {
  Write-Host '==> Installing Python via winget...'
  if (Test-Cmd 'winget') {
    winget install -e --id Python.Python.3.12 --silent --accept-source-agreements --accept-package-agreements
  } else {
    Write-Error 'winget not available; please install Python 3.12 first.'
    exit 1
  }
}

# Copy from this script's directory if present, else fetch from server
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
if (Test-Path (Join-Path $ScriptDir 'customrmm_agent.py')) {
  Copy-Item (Join-Path $ScriptDir 'customrmm_agent.py') (Join-Path $InstallDir 'agent.py') -Force
  Copy-Item (Join-Path $ScriptDir 'requirements.txt')   (Join-Path $InstallDir 'requirements.txt') -Force
} else {
  Write-Host '==> Fetching agent from server...'
  Invoke-WebRequest -UseBasicParsing -Uri "$RmmServer/install/agent.py" -OutFile (Join-Path $InstallDir 'agent.py')
  Invoke-WebRequest -UseBasicParsing -Uri "$RmmServer/install/agent-requirements.txt" -OutFile (Join-Path $InstallDir 'requirements.txt')
}

Push-Location $InstallDir
python -m venv venv
& .\venv\Scripts\python.exe -m pip install --upgrade pip
& .\venv\Scripts\python.exe -m pip install -r requirements.txt

Set-Content -Path (Join-Path $InstallDir '.env') -Value @"
RMM_SERVER=$RmmServer
RMM_TOKEN=$RmmToken
"@

$taskName = 'CustomRMM Agent'
schtasks /Delete /F /TN $taskName 2>$null | Out-Null

$tr = "`"$InstallDir\venv\Scripts\pythonw.exe`" `"$InstallDir\agent.py`""
schtasks /Create /F /SC ONSTART /RU SYSTEM /RL HIGHEST /TN $taskName /TR $tr | Out-Null
schtasks /Run /TN $taskName | Out-Null

Pop-Location
Write-Host '==> Done. Agent registered as scheduled task "CustomRMM Agent".'
