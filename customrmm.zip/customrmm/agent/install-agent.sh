#!/usr/bin/env bash
# CustomRMM agent installer (Linux / macOS) - standalone version.
# Use the dashboard's /install page for a personalized one-liner.
set -euo pipefail

if [[ -z "${RMM_SERVER:-}" || -z "${RMM_TOKEN:-}" ]]; then
  echo "Usage: sudo RMM_SERVER=https://rmm.example.com RMM_TOKEN=xxxxx ./install-agent.sh" >&2
  exit 1
fi

if [[ "$EUID" -ne 0 ]]; then
  echo "Please run with sudo." >&2
  exit 1
fi

UNAME="$(uname -s)"
case "$UNAME" in
  Linux)  PLATFORM=linux ;;
  Darwin) PLATFORM=darwin ;;
  *) echo "Unsupported OS: $UNAME" >&2; exit 1 ;;
esac

if [[ "$PLATFORM" == "linux" ]]; then
  if command -v apt-get >/dev/null 2>&1; then
    apt-get update -y
    apt-get install -y python3 python3-venv python3-pip curl ca-certificates
  elif command -v dnf >/dev/null 2>&1; then
    dnf install -y python3 python3-pip curl ca-certificates
  elif command -v yum >/dev/null 2>&1; then
    yum install -y python3 python3-pip curl ca-certificates
  fi
fi

INSTALL_DIR=/opt/customrmm-agent
mkdir -p "$INSTALL_DIR"

# Copy from this repo if available, else fetch from server
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
if [[ -f "$SCRIPT_DIR/customrmm_agent.py" ]]; then
  cp "$SCRIPT_DIR/customrmm_agent.py" "$INSTALL_DIR/agent.py"
  cp "$SCRIPT_DIR/requirements.txt" "$INSTALL_DIR/requirements.txt"
else
  curl -fsSL "$RMM_SERVER/install/agent.py" -o "$INSTALL_DIR/agent.py"
  curl -fsSL "$RMM_SERVER/install/agent-requirements.txt" -o "$INSTALL_DIR/requirements.txt"
fi

cd "$INSTALL_DIR"
python3 -m venv venv
./venv/bin/python -m pip install --upgrade pip
./venv/bin/python -m pip install -r requirements.txt

cat > "$INSTALL_DIR/.env" <<EOF
RMM_SERVER=$RMM_SERVER
RMM_TOKEN=$RMM_TOKEN
EOF
chmod 600 "$INSTALL_DIR/.env"

if [[ "$PLATFORM" == "linux" ]]; then
  cat >/etc/systemd/system/customrmm-agent.service <<EOF
[Unit]
Description=CustomRMM Agent
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
EnvironmentFile=$INSTALL_DIR/.env
WorkingDirectory=$INSTALL_DIR
ExecStart=$INSTALL_DIR/venv/bin/python $INSTALL_DIR/agent.py
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF
  systemctl daemon-reload
  systemctl enable --now customrmm-agent.service
  echo "==> Done. systemctl status customrmm-agent"
else
  PLIST=/Library/LaunchDaemons/com.customrmm.agent.plist
  cat > "$PLIST" <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN"
  "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key><string>com.customrmm.agent</string>
  <key>ProgramArguments</key>
  <array>
    <string>$INSTALL_DIR/venv/bin/python</string>
    <string>$INSTALL_DIR/agent.py</string>
  </array>
  <key>WorkingDirectory</key><string>$INSTALL_DIR</string>
  <key>EnvironmentVariables</key>
  <dict>
    <key>RMM_SERVER</key><string>$RMM_SERVER</string>
    <key>RMM_TOKEN</key><string>$RMM_TOKEN</string>
  </dict>
  <key>RunAtLoad</key><true/>
  <key>KeepAlive</key><true/>
  <key>StandardOutPath</key><string>/var/log/customrmm-agent.log</string>
  <key>StandardErrorPath</key><string>/var/log/customrmm-agent.log</string>
</dict>
</plist>
EOF
  chown root:wheel "$PLIST"
  launchctl unload "$PLIST" 2>/dev/null || true
  launchctl load -w "$PLIST"
  echo "==> Done."
fi
