# CustomRMM Agent

Cross-platform Python agent for the CustomRMM dashboard. Runs on Windows,
Linux, and macOS.

## What the agent collects

**Every 30 seconds (configurable):**
- CPU utilization (%)
- Memory utilization (%)
- Disk utilization on the root drive (%)
- Network rx/tx bytes per second
- 1-minute load average (Linux/macOS only)
- System uptime (seconds since boot)

**Every 6 hours:**
- Installed software list
  - Windows: from the Uninstall registry keys (HKLM, both 32-bit and 64-bit)
  - macOS: from `system_profiler SPApplicationsDataType`
  - Linux: from `dpkg-query` or `rpm -qa`
- Available patches / updates
  - Windows: from the Microsoft Update API (`Microsoft.Update.Session`)
  - macOS: from `softwareupdate -l`
  - Linux: from `apt-get -s upgrade` or `dnf check-update`
- Recent system events / log errors
  - Windows: error+critical entries from `Get-WinEvent` (System log)
  - macOS: errors from the unified log (`log show`)
  - Linux: error-priority entries from `journalctl`

**On demand:**
- Remote shell command execution (`bash`, `sh`, `powershell`, `cmd`, `python`)
- Saved-script execution from the dashboard's script library

## What the agent does NOT collect

- File contents or directory listings
- Screenshots or screen contents
- Keystrokes
- Microphone or camera input
- Browser history, cookies, or saved passwords
- Email or document contents
- Network packet captures

The agent only sends what is listed in "What the agent collects" above.

## Transport

The agent maintains two parallel connections to the dashboard:

1. **WebSocket** (`/ws/agent`) for live, low-latency command delivery.
2. **HTTP polling** (`/api/agent/checkin`) for metric uploads and as a
   fallback path if the WebSocket is unavailable.

If the WebSocket is connected, queued commands are pushed instantly. If
not, they are picked up on the next 30-second poll.

All requests authenticate with a per-agent bearer token issued at
enrollment.

## Files

- `customrmm_agent.py` — the agent itself
- `requirements.txt` — `psutil`, `requests`, `websocket-client`
- `install-agent.sh` — Linux/macOS installer (systemd / launchd)
- `install-agent.ps1` — Windows installer (scheduled task at boot, SYSTEM)

## Manual run (debugging)

```bash
RMM_SERVER=https://rmm.example.com \
RMM_TOKEN=your-enrollment-token \
python customrmm_agent.py
```

State is persisted in `state.json` next to the script. After the first
successful enrollment the agent stores its own auth token there and will
not need `RMM_TOKEN` again unless `state.json` is deleted.

## Uninstall

**Linux:**
```bash
sudo systemctl disable --now customrmm-agent
sudo rm -rf /etc/systemd/system/customrmm-agent.service /opt/customrmm-agent
sudo systemctl daemon-reload
```

**macOS:**
```bash
sudo launchctl unload /Library/LaunchDaemons/com.customrmm.agent.plist
sudo rm /Library/LaunchDaemons/com.customrmm.agent.plist
sudo rm -rf /opt/customrmm-agent
```

**Windows (elevated PowerShell):**
```powershell
schtasks /Delete /F /TN "CustomRMM Agent"
Remove-Item -Recurse -Force "C:\Program Files\CustomRMM"
```
