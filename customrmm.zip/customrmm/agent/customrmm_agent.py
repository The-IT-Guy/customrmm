"""CustomRMM cross-platform agent.

Runs WebSocket (live commands) and HTTP polling (metrics + fallback) in
parallel. Reports CPU/RAM/disk every 30s, full inventory every 6h.

Configuration (via env):
  RMM_SERVER  - Base URL of the dashboard, e.g. https://rmm.example.com
  RMM_TOKEN   - Enrollment token (used once, then replaced by an auth token)

State is persisted in ./state.json next to this script.
"""
from __future__ import annotations

import json
import logging
import os
import platform
import socket
import subprocess
import sys
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

import psutil
import requests
import websocket  # websocket-client


VERSION = "1.0.0"
HERE = Path(__file__).resolve().parent
STATE_PATH = HERE / "state.json"

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s | %(message)s")
log = logging.getLogger("rmm-agent")


# ---------------- helpers ----------------

def _os_family() -> str:
    s = platform.system().lower()
    if s.startswith("win"):
        return "windows"
    if s == "darwin":
        return "darwin"
    return "linux"


def _hostname() -> str:
    try:
        return socket.gethostname()
    except Exception:
        return "unknown"


def _private_ip() -> str:
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return ""


def _ws_url(base: str) -> str:
    base = base.rstrip("/")
    if base.startswith("https://"):
        return "wss://" + base[len("https://"):] + "/ws/agent"
    if base.startswith("http://"):
        return "ws://" + base[len("http://"):] + "/ws/agent"
    return base + "/ws/agent"


def _run(cmd: list[str], timeout: int = 60) -> tuple[int, str, str]:
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, shell=False)
        return p.returncode, p.stdout, p.stderr
    except subprocess.TimeoutExpired:
        return 124, "", "timeout"
    except Exception as e:  # noqa: BLE001
        return 1, "", str(e)


def _execute_command(shell: str, payload: str) -> tuple[int, str]:
    """Execute a queued command. Returns (exit_code, output)."""
    fam = _os_family()
    try:
        if shell in ("auto", ""):
            shell = "powershell" if fam == "windows" else "bash"

        if shell == "powershell":
            cmd = ["powershell", "-NoProfile", "-NonInteractive", "-Command", payload]
        elif shell == "cmd":
            cmd = ["cmd.exe", "/c", payload]
        elif shell == "bash":
            cmd = ["bash", "-lc", payload]
        elif shell == "sh":
            cmd = ["sh", "-c", payload]
        elif shell == "python":
            cmd = [sys.executable, "-c", payload]
        else:
            return 1, f"unknown shell: {shell}"

        rc, out, err = _run(cmd, timeout=600)
        combined = (out or "") + (("\n[stderr]\n" + err) if err else "")
        return rc, combined[-200_000:]
    except Exception as e:  # noqa: BLE001
        return 1, f"agent error: {e}"


# ---------------- inventory collectors ----------------

def _collect_software() -> list[dict[str, str]]:
    fam = _os_family()
    items: list[dict[str, str]] = []
    try:
        if fam == "windows":
            ps = (
                "Get-ItemProperty HKLM:\\Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\*,"
                "HKLM:\\Software\\Wow6432Node\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\* "
                "| Where-Object {$_.DisplayName} | Select-Object DisplayName,DisplayVersion,Publisher,InstallDate "
                "| ConvertTo-Json -Compress"
            )
            rc, out, _ = _run(["powershell", "-NoProfile", "-Command", ps], timeout=120)
            if rc == 0 and out.strip():
                try:
                    data = json.loads(out)
                except json.JSONDecodeError:
                    data = []
                if isinstance(data, dict):
                    data = [data]
                for d in data:
                    items.append({
                        "name": d.get("DisplayName", "") or "",
                        "version": d.get("DisplayVersion", "") or "",
                        "publisher": d.get("Publisher", "") or "",
                        "install_date": d.get("InstallDate", "") or "",
                    })
        elif fam == "darwin":
            rc, out, _ = _run(["/usr/sbin/system_profiler", "-json", "SPApplicationsDataType"], timeout=120)
            if rc == 0 and out:
                try:
                    data = json.loads(out)
                except json.JSONDecodeError:
                    data = {}
                for d in data.get("SPApplicationsDataType", []):
                    items.append({
                        "name": d.get("_name", ""),
                        "version": d.get("version", "") or "",
                        "publisher": d.get("info", "") or "",
                        "install_date": d.get("lastModified", "") or "",
                    })
        else:
            rc, out, _ = _run(["dpkg-query", "-W", "-f=${Package}\\t${Version}\\t${Maintainer}\\n"], timeout=60)
            if rc == 0 and out:
                for line in out.splitlines():
                    parts = line.split("\t")
                    if len(parts) >= 2:
                        items.append({
                            "name": parts[0], "version": parts[1],
                            "publisher": parts[2] if len(parts) > 2 else "", "install_date": "",
                        })
            else:
                rc, out, _ = _run(["rpm", "-qa", "--qf", "%{NAME}\\t%{VERSION}-%{RELEASE}\\t%{VENDOR}\\n"], timeout=60)
                if rc == 0:
                    for line in out.splitlines():
                        parts = line.split("\t")
                        if len(parts) >= 2:
                            items.append({
                                "name": parts[0], "version": parts[1],
                                "publisher": parts[2] if len(parts) > 2 else "", "install_date": "",
                            })
    except Exception as e:  # noqa: BLE001
        log.warning(f"software inventory failed: {e}")
    return items[:2000]


def _collect_patches() -> list[dict[str, Any]]:
    fam = _os_family()
    items: list[dict[str, Any]] = []
    try:
        if fam == "windows":
            ps = (
                "$Session = New-Object -ComObject Microsoft.Update.Session;"
                "$Searcher = $Session.CreateUpdateSearcher();"
                "$Result = $Searcher.Search(\"IsInstalled=0 and Type='Software' and IsHidden=0\");"
                "$out = @(); foreach ($u in $Result.Updates) {"
                "  $kb = ($u.KBArticleIDs | ForEach-Object {\"KB$_\"}) -join ',';"
                "  $out += [pscustomobject]@{ Name=$u.Title; KB=$kb; Severity=$u.MsrcSeverity };"
                "}"
                "$out | ConvertTo-Json -Compress"
            )
            rc, out, _ = _run(["powershell", "-NoProfile", "-Command", ps], timeout=300)
            if rc == 0 and out.strip():
                try:
                    data = json.loads(out)
                except json.JSONDecodeError:
                    data = []
                if isinstance(data, dict):
                    data = [data]
                for d in data:
                    items.append({
                        "name": d.get("Name", ""), "kb": d.get("KB", ""),
                        "severity": (d.get("Severity") or "info"), "available": True,
                    })
        elif fam == "darwin":
            rc, out, _ = _run(["/usr/sbin/softwareupdate", "-l"], timeout=120)
            if rc == 0:
                for line in out.splitlines():
                    line = line.strip()
                    if line.startswith("* Label:") or line.startswith("*"):
                        items.append({"name": line.lstrip("*").strip(), "kb": "", "severity": "info", "available": True})
        else:
            if Path("/usr/bin/apt-get").exists() or Path("/usr/bin/apt").exists():
                _run(["apt-get", "-q", "update"], timeout=120)
                rc, out, _ = _run(["apt-get", "-s", "upgrade"], timeout=120)
                if rc == 0:
                    for line in out.splitlines():
                        if line.startswith("Inst "):
                            parts = line.split()
                            if len(parts) >= 2:
                                items.append({"name": parts[1], "kb": "", "severity": "info", "available": True})
            elif Path("/usr/bin/dnf").exists():
                rc, out, _ = _run(["dnf", "-q", "check-update"], timeout=120)
                for line in out.splitlines():
                    parts = line.split()
                    if len(parts) >= 3 and "." in parts[0]:
                        items.append({"name": parts[0], "kb": "", "severity": "info", "available": True})
    except Exception as e:  # noqa: BLE001
        log.warning(f"patch inventory failed: {e}")
    return items[:1000]


def _collect_events() -> list[dict[str, Any]]:
    fam = _os_family()
    items: list[dict[str, Any]] = []
    try:
        if fam == "windows":
            ps = (
                "Get-WinEvent -FilterHashtable @{LogName='System';Level=1,2,3} -MaxEvents 50 -ErrorAction SilentlyContinue "
                "| Select-Object TimeCreated,LevelDisplayName,Id,ProviderName,Message "
                "| ConvertTo-Json -Compress"
            )
            rc, out, _ = _run(["powershell", "-NoProfile", "-Command", ps], timeout=120)
            if rc == 0 and out.strip():
                try:
                    data = json.loads(out)
                except json.JSONDecodeError:
                    data = []
                if isinstance(data, dict):
                    data = [data]
                for d in data:
                    lvl = (d.get("LevelDisplayName") or "info").lower()
                    if lvl.startswith("crit"): lvl = "critical"
                    elif lvl.startswith("err"): lvl = "error"
                    elif lvl.startswith("warn"): lvl = "warning"
                    else: lvl = "info"
                    items.append({
                        "source": d.get("ProviderName", "system"),
                        "level": lvl, "code": str(d.get("Id", "")),
                        "message": (d.get("Message") or "")[:1000],
                    })
        elif fam == "darwin":
            rc, out, _ = _run(["log", "show", "--last", "30m", "--predicate", 'eventMessage CONTAINS[c] "error"', "--style", "compact"], timeout=60)
            if rc == 0:
                for line in out.splitlines()[-50:]:
                    if line.strip():
                        items.append({"source": "system", "level": "error", "code": "", "message": line[:1000]})
        else:
            rc, out, _ = _run(["journalctl", "-p", "err", "-n", "50", "--no-pager", "--output", "short"], timeout=60)
            if rc == 0:
                for line in out.splitlines():
                    if line.strip():
                        items.append({"source": "journald", "level": "error", "code": "", "message": line[:1000]})
    except Exception as e:  # noqa: BLE001
        log.warning(f"event collection failed: {e}")
    return items[:200]


# ---------------- state + server proto ----------------

@dataclass
class State:
    agent_id: str = ""
    auth_token: str = ""
    websocket_url: str = ""
    poll_interval: int = 30
    last_inventory: float = 0.0

    @classmethod
    def load(cls) -> "State":
        if STATE_PATH.exists():
            try:
                return cls(**json.loads(STATE_PATH.read_text()))
            except Exception:
                pass
        return cls()

    def save(self) -> None:
        STATE_PATH.write_text(json.dumps(self.__dict__))


@dataclass
class Server:
    base: str
    enrollment_token: str
    state: State = field(default_factory=State)
    _net_prev: dict = field(default_factory=dict)

    def headers(self) -> dict:
        return {"Authorization": f"Bearer {self.state.auth_token}"} if self.state.auth_token else {}

    def enroll(self) -> None:
        body = {
            "enrollment_token": self.enrollment_token,
            "hostname": _hostname(),
            "os_family": _os_family(),
            "os_version": platform.platform(),
            "arch": platform.machine(),
            "agent_version": VERSION,
            "private_ip": _private_ip(),
        }
        r = requests.post(f"{self.base.rstrip('/')}/api/agent/enroll", json=body, timeout=30)
        r.raise_for_status()
        d = r.json()
        self.state.agent_id = d["agent_id"]
        self.state.auth_token = d["auth_token"]
        self.state.websocket_url = d.get("websocket_url", _ws_url(self.base))
        self.state.poll_interval = d.get("poll_interval_seconds", 30)
        self.state.save()
        log.info(f"enrolled as {self.state.agent_id}")

    def collect_metrics(self) -> dict:
        cpu = psutil.cpu_percent(interval=0.5)
        mem = psutil.virtual_memory().percent
        # Disk: use root drive
        try:
            root = "C:\\" if _os_family() == "windows" else "/"
            disk = psutil.disk_usage(root).percent
        except Exception:
            disk = 0.0
        # Network rate
        net = psutil.net_io_counters()
        now = time.time()
        rx_bps = tx_bps = 0.0
        if self._net_prev:
            dt = max(0.001, now - self._net_prev["t"])
            rx_bps = (net.bytes_recv - self._net_prev["rx"]) / dt
            tx_bps = (net.bytes_sent - self._net_prev["tx"]) / dt
        self._net_prev = {"t": now, "rx": net.bytes_recv, "tx": net.bytes_sent}
        load_1m = 0.0
        try:
            if hasattr(os, "getloadavg"):
                load_1m = os.getloadavg()[0]
        except Exception:
            pass
        return {
            "cpu_pct": cpu, "mem_pct": mem, "disk_pct": disk,
            "net_rx_bps": rx_bps, "net_tx_bps": tx_bps, "load_1m": load_1m,
            "uptime_seconds": int(time.time() - psutil.boot_time()),
        }

    def checkin(self, metrics: dict) -> dict:
        r = requests.post(f"{self.base.rstrip('/')}/api/agent/checkin",
                          json=metrics, headers=self.headers(), timeout=30)
        r.raise_for_status()
        return r.json()

    def report_command(self, cmd_id: int, status: str, output: str, exit_code: Optional[int]) -> None:
        try:
            requests.post(f"{self.base.rstrip('/')}/api/agent/command-result",
                          json={"id": cmd_id, "status": status, "output": output, "exit_code": exit_code},
                          headers=self.headers(), timeout=30)
        except Exception as e:  # noqa: BLE001
            log.warning(f"failed to report command {cmd_id}: {e}")

    def send_inventory(self) -> None:
        body = {
            "software": _collect_software(),
            "patches": _collect_patches(),
            "events": _collect_events(),
        }
        try:
            r = requests.post(f"{self.base.rstrip('/')}/api/agent/inventory",
                              json=body, headers=self.headers(), timeout=120)
            r.raise_for_status()
            self.state.last_inventory = time.time()
            self.state.save()
            log.info(f"inventory: software={len(body['software'])} patches={len(body['patches'])} events={len(body['events'])}")
        except Exception as e:  # noqa: BLE001
            log.warning(f"inventory upload failed: {e}")


# ---------------- worker loops ----------------

def _ws_loop(server: Server, stop: threading.Event) -> None:
    while not stop.is_set():
        try:
            url = server.state.websocket_url + f"?token={server.state.auth_token}"
            ws = websocket.WebSocket()
            ws.connect(url, timeout=15)
            log.info("ws connected")
            ws.send(json.dumps({"type": "hello", "version": VERSION}))
            ws.settimeout(60)
            while not stop.is_set():
                try:
                    raw = ws.recv()
                except websocket.WebSocketTimeoutException:
                    try:
                        ws.send(json.dumps({"type": "ping"}))
                        continue
                    except Exception:
                        break
                if not raw:
                    break
                try:
                    msg = json.loads(raw)
                except json.JSONDecodeError:
                    continue
                mtype = msg.get("type")
                if mtype == "command":
                    cid = msg["id"]
                    log.info(f"ws command id={cid} shell={msg.get('shell')}")
                    rc, out = _execute_command(msg.get("shell", "auto"), msg.get("payload", ""))
                    try:
                        ws.send(json.dumps({
                            "type": "command_result",
                            "id": cid, "status": "done" if rc == 0 else "error",
                            "output": out, "exit_code": rc,
                        }))
                    except Exception:
                        server.report_command(cid, "done" if rc == 0 else "error", out, rc)
                elif mtype == "pong":
                    pass
            try: ws.close()
            except Exception: pass
        except Exception as e:  # noqa: BLE001
            log.info(f"ws not connected: {e}")
        for _ in range(15):
            if stop.is_set(): return
            time.sleep(1)


def _http_loop(server: Server, stop: threading.Event) -> None:
    """HTTP polling. Posts metrics every poll_interval seconds, runs commands
    that came through the polling path (when WS is down)."""
    inventory_interval = 6 * 3600
    while not stop.is_set():
        try:
            metrics = server.collect_metrics()
            resp = server.checkin(metrics)
            for cmd in resp.get("pending_commands", []):
                cid = cmd["id"]
                log.info(f"http command id={cid} shell={cmd.get('shell')}")
                rc, out = _execute_command(cmd.get("shell", "auto"), cmd.get("payload", ""))
                server.report_command(cid, "done" if rc == 0 else "error", out, rc)
        except Exception as e:  # noqa: BLE001
            log.warning(f"checkin failed: {e}")

        # Inventory every 6h
        if time.time() - server.state.last_inventory > inventory_interval:
            server.send_inventory()

        for _ in range(server.state.poll_interval):
            if stop.is_set(): return
            time.sleep(1)


# ---------------- entry ----------------

def main() -> None:
    base = os.environ.get("RMM_SERVER", "").strip()
    enroll_token = os.environ.get("RMM_TOKEN", "").strip()
    if not base:
        log.error("RMM_SERVER not set")
        sys.exit(1)

    server = Server(base=base, enrollment_token=enroll_token, state=State.load())

    if not server.state.auth_token:
        if not enroll_token:
            log.error("RMM_TOKEN not set and no prior enrollment found")
            sys.exit(1)
        server.enroll()
        # First inventory shortly after enroll
        try:
            server.send_inventory()
        except Exception as e:  # noqa: BLE001
            log.warning(f"initial inventory failed (will retry): {e}")

    stop = threading.Event()
    t_ws = threading.Thread(target=_ws_loop, args=(server, stop), daemon=True, name="rmm-ws")
    t_http = threading.Thread(target=_http_loop, args=(server, stop), daemon=True, name="rmm-http")
    t_ws.start()
    t_http.start()

    try:
        while True:
            time.sleep(60)
    except KeyboardInterrupt:
        log.info("shutting down")
        stop.set()


if __name__ == "__main__":
    main()
