#!/usr/bin/env python3
"""Generate a SECRET_KEY value for .env"""
import secrets
print(secrets.token_urlsafe(64))
